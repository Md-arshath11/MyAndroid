package com.example.weather.network

data class WeatherModel(
    val current: Current,
    val location: Location
)
package com.example.weather.network

data class Condition(
    val code: String,
    val icon: String,
    val text: String
)
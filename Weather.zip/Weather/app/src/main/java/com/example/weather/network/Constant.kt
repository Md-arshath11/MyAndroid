package com.example.weather.network

object Constant {
    val apiKey = "62bb4ff239974c30a1895758250406"
}